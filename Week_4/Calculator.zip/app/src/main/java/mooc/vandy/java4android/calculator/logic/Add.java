package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Add operation.
 */
public class Add {
    // TODO -- start your code here
        private int numOne = 0;
        private int numTwo = 0;

        public Add(int argumentOne, int argumentTwo) {
            numOne = argumentOne;
            numTwo = argumentTwo;
        }

        public String toString() {
            return String.valueOf(numOne + numTwo);
        }
}
